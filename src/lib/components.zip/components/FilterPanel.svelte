<script>
  import { createEventDispatcher } from 'svelte'
  import { X } from 'lucide-svelte'

  const dispatch = createEventDispatcher()

  export let positions = []
  export let priceRange = { min: 0, max: 0 }
  export let wageRange = { min: 0, max: 0 }
  export let allTags = []
  export let filters = {
    name: '',
    position: [],
    priceRange: null,
    wageRange: null,
    heightRange: null,
    contractExpiry: null,
    tags: []
  }

  let localFilters = { ...filters }
  let expandedSections = {
    search: true,
    position: true,
    price: false,
    wage: false,
    contract: false,
    tags: false
  }

  function updateFilters() {
    dispatch('change', localFilters)
  }

  function togglePosition(pos) {
    const idx = localFilters.position.indexOf(pos)
    if (idx > -1) {
      localFilters.position.splice(idx, 1)
    } else {
      localFilters.position.push(pos)
    }
    localFilters.position = localFilters.position
    updateFilters()
  }

  function toggleTag(tag) {
    const idx = localFilters.tags.indexOf(tag)
    if (idx > -1) {
      localFilters.tags.splice(idx, 1)
    } else {
      localFilters.tags.push(tag)
    }
    localFilters.tags = localFilters.tags
    updateFilters()
  }

  function setPriceRange(min, max) {
    localFilters.priceRange = min !== null || max !== null ? { min, max } : null
    updateFilters()
  }

  function setWageRange(min, max) {
    localFilters.wageRange = min !== null || max !== null ? { min, max } : null
    updateFilters()
  }

  function resetFilters() {
    localFilters = {
      name: '',
      position: [],
      priceRange: null,
      wageRange: null,
      heightRange: null,
      contractExpiry: null,
      tags: []
    }
    updateFilters()
  }

  $: if (filters) localFilters = { ...filters }
</script>

<div class="bg-slate-800 rounded-lg border border-slate-700 p-4 space-y-4 sticky top-24">
  <div class="flex items-center justify-between">
    <h2 class="text-lg font-semibold text-slate-50">Filters</h2>
    <button
      on:click={resetFilters}
      class="text-xs text-accent-light hover:text-accent-light/80 transition-colors"
    >
      Reset
    </button>
  </div>

  <!-- Search -->
  <div class="space-y-2">
    <label class="block text-sm font-medium text-slate-300">Player Name</label>
    <input
      type="text"
      bind:value={localFilters.name}
      on:input={updateFilters}
      placeholder="Search..."
      class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-slate-50 placeholder-slate-500 focus:outline-none focus:border-accent-light transition-colors"
    />
  </div>

  <!-- Position -->
  <div class="space-y-2">
    <button
      on:click={() => (expandedSections.position = !expandedSections.position)}
      class="w-full flex items-center justify-between text-sm font-medium text-slate-300 hover:text-slate-50 transition-colors"
    >
      <span>Position</span>
      <span class="text-xs text-slate-500">
        {localFilters.position.length > 0 ? `(${localFilters.position.length})` : ''}
      </span>
    </button>
    {#if expandedSections.position}
      <div class="flex flex-wrap gap-2">
        {#each positions as pos (pos)}
          <button
            on:click={() => togglePosition(pos)}
            class="px-2 py-1 text-xs rounded transition-colors {localFilters.position.includes(pos)
              ? 'bg-accent-light text-slate-900'
              : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}"
          >
            {pos}
          </button>
        {/each}
      </div>
    {/if}
  </div>

  <!-- Asking Price Range -->
  <div class="space-y-2">
    <button
      on:click={() => (expandedSections.price = !expandedSections.price)}
      class="w-full flex items-center justify-between text-sm font-medium text-slate-300 hover:text-slate-50 transition-colors"
    >
      <span>Asking Price</span>
    </button>
    {#if expandedSections.price}
      <div class="space-y-2">
        <div>
          <label class="text-xs text-slate-400">Min (£M)</label>
          <input
            type="number"
            placeholder="0"
            value={localFilters.priceRange?.min || ''}
            on:change={(e) => setPriceRange(e.target.value ? parseInt(e.target.value) * 1000000 : null, localFilters.priceRange?.max)}
            class="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-slate-50 text-sm focus:outline-none focus:border-accent-light"
          />
        </div>
        <div>
          <label class="text-xs text-slate-400">Max (£M)</label>
          <input
            type="number"
            placeholder={Math.round(priceRange.max / 1000000)}
            value={localFilters.priceRange?.max ? Math.round(localFilters.priceRange.max / 1000000) : ''}
            on:change={(e) => setPriceRange(localFilters.priceRange?.min, e.target.value ? parseInt(e.target.value) * 1000000 : null)}
            class="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-slate-50 text-sm focus:outline-none focus:border-accent-light"
          />
        </div>
      </div>
    {/if}
  </div>

  <!-- Wage Range -->
  <div class="space-y-2">
    <button
      on:click={() => (expandedSections.wage = !expandedSections.wage)}
      class="w-full flex items-center justify-between text-sm font-medium text-slate-300 hover:text-slate-50 transition-colors"
    >
      <span>Weekly Wage</span>
    </button>
    {#if expandedSections.wage}
      <div class="space-y-2">
        <div>
          <label class="text-xs text-slate-400">Min (£k)</label>
          <input
            type="number"
            placeholder="0"
            value={localFilters.wageRange?.min ? Math.round(localFilters.wageRange.min / 1000) : ''}
            on:change={(e) => setWageRange(e.target.value ? parseInt(e.target.value) * 1000 : null, localFilters.wageRange?.max)}
            class="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-slate-50 text-sm focus:outline-none focus:border-accent-light"
          />
        </div>
        <div>
          <label class="text-xs text-slate-400">Max (£k)</label>
          <input
            type="number"
            placeholder={Math.round(wageRange.max / 1000)}
            value={localFilters.wageRange?.max ? Math.round(localFilters.wageRange.max / 1000) : ''}
            on:change={(e) => setWageRange(localFilters.wageRange?.min, e.target.value ? parseInt(e.target.value) * 1000 : null)}
            class="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-slate-50 text-sm focus:outline-none focus:border-accent-light"
          />
        </div>
      </div>
    {/if}
  </div>

  <!-- Contract Expiry -->
  <div class="space-y-2">
    <button
      on:click={() => (expandedSections.contract = !expandedSections.contract)}
      class="w-full flex items-center justify-between text-sm font-medium text-slate-300 hover:text-slate-50 transition-colors"
    >
      <span>Contract Expiry</span>
    </button>
    {#if expandedSections.contract}
      <div class="space-y-2">
        <div>
          <label class="text-xs text-slate-400">Before</label>
          <input
            type="date"
            value={localFilters.contractExpiry?.before || ''}
            on:change={(e) => {
              localFilters.contractExpiry = {
                ...localFilters.contractExpiry,
                before: e.target.value || null
              }
              updateFilters()
            }}
            class="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-slate-50 text-sm focus:outline-none focus:border-accent-light"
          />
        </div>
        <div>
          <label class="text-xs text-slate-400">After</label>
          <input
            type="date"
            value={localFilters.contractExpiry?.after || ''}
            on:change={(e) => {
              localFilters.contractExpiry = {
                ...localFilters.contractExpiry,
                after: e.target.value || null
              }
              updateFilters()
            }}
            class="w-full px-2 py-1 bg-slate-700 border border-slate-600 rounded text-slate-50 text-sm focus:outline-none focus:border-accent-light"
          />
        </div>
      </div>
    {/if}
  </div>

  <!-- Tags -->
  {#if allTags.length > 0}
    <div class="space-y-2">
      <button
        on:click={() => (expandedSections.tags = !expandedSections.tags)}
        class="w-full flex items-center justify-between text-sm font-medium text-slate-300 hover:text-slate-50 transition-colors"
      >
        <span>Tags</span>
        <span class="text-xs text-slate-500">
          {localFilters.tags.length > 0 ? `(${localFilters.tags.length})` : ''}
        </span>
      </button>
      {#if expandedSections.tags}
        <div class="space-y-1 max-h-40 overflow-y-auto">
          {#each allTags as tag (tag)}
            <label class="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={localFilters.tags.includes(tag)}
                on:change={() => toggleTag(tag)}
                class="rounded bg-slate-700 border-slate-600 text-accent-light focus:ring-accent-light"
              />
              <span class="text-sm text-slate-300">{tag}</span>
            </label>
          {/each}
        </div>
      {/if}
    </div>
  {/if}
</div>
